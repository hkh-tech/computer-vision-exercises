import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import imread
from skimage.transform import resize as imresize
from scipy.ndimage import convolve as conv2
from scipy.ndimage import convolve1d as conv1
from scipy.ndimage import gaussian_filter, map_coordinates
from numpy.fft import fftshift, fft2

# Import custom utils provided in the assignment
from utils import imnoise, gaussian2, bilateral_filter, affinefit

def task2_denoising():
    print("Running Task 2: Image Denoising...")
    
    # Load and prep image
    im = imread('einsteinpic.jpg') / 255.
    im = imresize(im, (256, 256))

    # Add noise
    imns = imnoise(im, 'salt & pepper', 0.05) * 1.
    imng = im + 0.05 * np.random.randn(im.shape[0], im.shape[1])

    # Gaussian filtering (Separable implementation)
    sigmad = 2.5
    g, _, _, _, _, _, = gaussian2(sigmad)
    
    # Use SVD to get 1D kernels
    U, S, Vt = np.linalg.svd(g)
    v_kernel = np.sqrt(S[0]) * U[:, 0]
    h_kernel = np.sqrt(S[0]) * Vt[0, :]

    # Apply 1D filters
    gflt_imns = conv1(imns, v_kernel, axis=0, mode='reflect')
    gflt_imns = conv1(gflt_imns, h_kernel, axis=1, mode='reflect')

    gflt_imng = conv1(imng, v_kernel, axis=0, mode='reflect')
    gflt_imng = conv1(gflt_imng, h_kernel, axis=1, mode='reflect')

    # Median filter implementation
    def median_filter(img, wsize):
        rows, cols = img.shape
        out = np.zeros((rows, cols))
        k = int((wsize - 1) / 2)
        for i in range(rows):
            for j in range(cols):
                r_min, r_max = max(i-k, 0), min(i+k, rows-1)
                c_min, c_max = max(j-k, 0), min(j+k, cols-1)
                patch = img[r_min:r_max+1, c_min:c_max+1]
                out[i, j] = np.median(patch)
        return out

    medflt_imns = median_filter(imns, 5)
    medflt_imng = median_filter(imng, 5)

    # Bilateral filtering
    wsize = 11
    sigma_d, sigma_r = 2.5, 0.1
    bflt_imns = bilateral_filter(imns, wsize, sigma_d, sigma_r)
    bflt_imng = bilateral_filter(imng, wsize, sigma_d, sigma_r)

    # Plotting results
    plt.figure(figsize=(12, 6))
    titles = ["Noisy (S&P)", "Gaussian", "Median", "Bilateral", "Noisy (Gauss)", "Gaussian", "Median", "Bilateral"]
    imgs = [imns, gflt_imns, medflt_imns, bflt_imns, imng, gflt_imng, medflt_imng, bflt_imng]
    for i in range(8):
        plt.subplot(2, 4, i+1)
        plt.imshow(imgs[i], cmap='gray')
        plt.title(titles[i])
        plt.axis('off')
    plt.tight_layout()
    plt.show()

def task3_hybrid():
    print("Running Task 3: Hybrid Images...")
    
    man = imread('man.jpg') / 255.
    wolf = imread('wolf.jpg') / 255.

    # Alignment points
    man_pts = np.array([[502, 465], [714, 485], [594, 875]])
    wolf_pts = np.array([[851, 919], [1159, 947], [975, 1451]])

    # Align wolf to man
    A, b = affinefit(man_pts, wolf_pts)
    xv, yv = np.meshgrid(np.arange(man.shape[1]), np.arange(man.shape[0]))
    pt = np.dot(A, np.vstack([xv.flatten(), yv.flatten()])) + np.tile(b, (xv.size, 1)).T
    wolft = map_coordinates(wolf, (pt[1,:].reshape(man.shape), pt[0,:].reshape(man.shape)))

    # Filtering
    sA, sB = 16, 8
    man_lp = gaussian_filter(man, sA, mode='nearest')
    wolf_lp = gaussian_filter(wolft, sB, mode='nearest')
    wolf_hp = wolft - wolf_lp
    
    hybrid = man_lp + wolf_hp

    # Fourier Transforms
    f_man = fftshift(fft2(man))
    f_man_lp = fftshift(fft2(man_lp))
    f_wolf = fftshift(fft2(wolft))
    f_wolf_hp = fftshift(fft2(wolf_hp))

    # Plotting
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1); plt.imshow(hybrid, cmap='gray'); plt.title("Hybrid Image")
    plt.subplot(1, 2, 2); plt.imshow(man + wolft, cmap='gray'); plt.title("Simple Blend")
    
    plt.figure(figsize=(10, 8))
    f_titles = ["Man FFT", "Man LP FFT", "Wolf FFT", "Wolf HP FFT"]
    f_imgs = [f_man, f_man_lp, f_wolf, f_wolf_hp]
    for i in range(4):
        plt.subplot(2, 2, i+1)
        plt.imshow(np.log(np.abs(f_imgs[i])), cmap='gray')
        plt.title(f_titles[i])
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    task2_denoising()
    task3_hybrid()
