import numpy as np


def estimateF(x1, x2):
    """
    :param x1: Points from image 1, with shape (coordinates, point_id)
    :param x2: Points from image 2, with shape (coordinates, point_id)
    :return F: Estimated fundamental matrix
    """

    # Use x1 and x2 to construct the equation for homogeneous linear system
    ##-your-code-start-here--##
    num_points = x1.shape[1]
    A = np.zeros((num_points, 9))
    
    for i in range(num_points):
        u, v, _ = x1[:, i]
        up, vp, _ = x2[:, i]
        A[i] = [up*u, up*v, up, vp*u, vp*v, vp, u, v, 1]
    ##--your-code-ends-here--##

    # Use SVD to find the solution for this homogeneous linear system by
    # extracting the row from V corresponding to the smallest singular value.
    ##-your-code-start-here--##
    U, S, Vh = np.linalg.svd(A)
    v_min = Vh[-1, :]
    ##--your-code-ends-here--##
    F = np.reshape(v_min, (3, 3))  # reshape to acquire Fundamental matrix F

    # Enforce constraint that fundamental matrix has rank 2 by performing
    # SVD and then reconstructing with only the two largest singular values
    # Reconstruction is done with u @ s @ vh where s is the singular values
    # in a diagonal form.
    ##-your-code-start-here--##
    U, S, Vh = np.linalg.svd(F)
    S[2] = 0 # Enforce rank 2
    F = U @ np.diag(S) @ Vh
    ##--your-code-ends-here--##
    
    return F
