import numpy as np


def camcalibDLT(x_world, x_im):
    """
    :param x_world: World coordinatesm with shape (point_id, coordinates)
    :param x_im: Image coordinates with shape (point_id, coordinates)
    :return P: Camera projection matrix with shape (3,4)
    """

    # Create the matrix A 
    ##-your-code-starts-here-##
    num_points = x_world.shape[0]
    A = []
    for i in range(num_points):
        X = x_world[i]
        x, y, w = x_im[i]
        A.append([0, 0, 0, 0, -w*X[0], -w*X[1], -w*X[2], -w*X[3], y*X[0], y*X[1], y*X[2], y*X[3]])
        A.append([w*X[0], w*X[1], w*X[2], w*X[3], 0, 0, 0, 0, -x*X[0], -x*X[1], -x*X[2], -x*X[3]])
    A = np.array(A)
    ##-your-code-ends-here-##
    
    # Perform homogeneous least squares fitting.
    # The best solution is given by the eigenvector of
    # A.T*A with the smallest eigenvalue.
    ##-your-code-starts-here-##
    U, S, Vh = np.linalg.svd(A)
    ev = Vh[-1, :]
    ##-your-code-ends-here-##
    
    # Reshape the eigenvector into a projection matrix P
    P = np.reshape(ev, (3, 4))  # here ev is the eigenvector from above
    # P = np.array([[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 1]], dtype=float)  # remove this and uncomment the line above
    
    return P
