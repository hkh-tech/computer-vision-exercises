import numpy as np


def trianglin(P1, P2, x1, x2):
    """
    :param P1: Projection matrix for image 1 with shape (3,4)
    :param P2: Projection matrix for image 2 with shape (3,4)
    :param x1: Image coordinates for a point in image 1
    :param x2: Image coordinates for a point in image 2
    :return X: Triangulated world coordinates
    """
    
    # Form A and get the least squares solution from the eigenvector 
    # corresponding to the smallest eigenvalue
    ##-your-code-starts-here-##
    def skew(x):
        return np.array([[0, -x[2], x[1]],
                         [x[2], 0, -x[0]],
                         [-x[1], x[0], 0]])
    
    A1 = skew(x1) @ P1
    A2 = skew(x2) @ P2
    A = np.vstack((A1[:2, :], A2[:2, :])) # Use only two rows from each skew-product
    
    U, S, Vh = np.linalg.svd(A)
    X = Vh[-1, :]
    ##-your-code-ends-here-##

    # X = np.array([0, 0, 0, 1])  # remove me
    
    return X
